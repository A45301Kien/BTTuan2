package com.example.myapplication.tuan3

class T3Contact {
    var ten: String? = null
    var tuoi: String? = null
    var hinh: Int = 0

    constructor()
    constructor(ten: String?, tuoi: String?, hinh: Int) {
        this.ten = ten
        this.tuoi=tuoi
        this.hinh=hinh
    }


}